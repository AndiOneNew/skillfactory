// Абстракция данных пользователя
protocol UserData {
  var userName: String { get }    //Имя пользователя
  var userCardId: String { get }   //Номер карты
  var userCardPin: Int { get }       //Пин-код
  var userCash: Float { get set}   //Наличные пользователя
  var userBankDeposit: Float { get set}   //Банковский депозит
  var userPhone: String { get }       //Номер телефона
  var useerPhoneBalance: Float { get set}    //Баланс телефона
}
// Абстракция банкомата и его функций
protocol BankApi {
  func showUserBalance()
  func showUserToppedUpMobilePhoneCash(cash: Float)
  func showUserToppedUpMobilePhoneDeposite(deposite: Float)
  func showWithdrawalDeposit(cash: Float)
  func showTopUpAccount(cash: Float)
  func showError(error: TextErrors)
 
  func checkUserPhone(phone: String) -> Bool
  func checkMaxUserCash(cash: Float) -> Bool
  func checkMaxAccountDeposit(withdraw: Float) -> Bool
  func checkCurrentUser(userCardId: String, userCardPin: Int) -> Bool
 
  mutating func topUpPhoneBalanceCash(pay: Float)
  mutating func topUpPhoneBalanceDeposit(pay: Float)
  mutating func getCashFromDeposit(cash: Float)
  mutating func putCashDeposit(topUp: Float)
}

// Тексты ошибок
enum TextErrors: String {
    case incorrect_data_card = "Неверно введены данные карты"
    case incorrect_data_phone = "Неверно введен ваш номер"
    case incorrect_cash = "У вас не хватает наличных средств"
    case incorrect_deposit = "У вас не хватает денежных средств на депозите"
}
 
// Виды операций, выбранных пользователем (подтверждение выбора)
enum DescriptionTypesAvailableOperations: String {
    case viewBalance = "Вы выбрали операцию запрос баланса"
    case topUpPhoneBalance = "Вы выбрали операцию поплнения баланса телефона"
    case topUpDeposite = "Вы выбрали операцию пополнения депозита"
    case withdrawDeposite = "Вы выбрали оперцию снятие средств с депозита"
}
 
// Действия, которые пользователь может выбирать в банкомате (имитация кнопок)
enum UserActions {
    case userChooseViewBalance
    case userChooseTopUpPhoneBalance (topUpPhoneBalance: String)
    case userChooseTopUpDeposite (topUpDeposite: Float)
    case userChooseWithdrawDeposite (withdrawDeposite: Float)
}
 
// Способ оплаты/пополнения наличными или через депозит
enum PaymentMethod {
    case cash (cash: Float)
    case deposite (deposite: Float)
}

struct User:UserData {
    var userName: String
    var userCardId: String
    var userCardPin: Int
    var userCash: Float
    var userBankDeposit: Float
    var userPhone: String
    var useerPhoneBalance: Float
}

// Банкомат
class ATM {
  private let userCardId: String
  private let userCardPin: Int
  private var someBank: BankApi
  private let action: UserActions
  private let paymentMethod: PaymentMethod?
 
  init(userCardId: String, userCardPin: Int, someBank: BankApi, action: UserActions, paymentMethod: PaymentMethod? = nil) {
    self.userCardId = userCardId
    self.userCardPin = userCardPin
    self.someBank = someBank
    self.action = action
    self.paymentMethod = paymentMethod
 
    sendUserDataToBank(userCardId: userCardId, userCardPin: userCardPin, action: action, payment: paymentMethod )
  }
 
 
  public final func sendUserDataToBank(userCardId: String, userCardPin: Int, action: UserActions, payment: PaymentMethod?) {
    let someUser = someBank.checkCurrentUser(userCardId: userCardId, userCardPin: userCardPin)
    if someUser {
        switch action {
        case .userChooseViewBalance:
            someBank.showUserBalance()
        case let .userChooseTopUpPhoneBalance(topUpPhoneBalance):
            if someBank.checkUserPhone(phone: topUpPhoneBalance){
                if let payment = payment {
                    switch payment {
                    case let .cash(cash: payment):
                        if someBank.checkMaxUserCash(cash: payment) {
                            someBank.topUpPhoneBalanceCash(pay: payment)
                            someBank.showUserToppedUpMobilePhoneCash(cash: payment)
                        }
                        else {
                            someBank.showError(error: .incorrect_cash)
                        }
                    case let .deposite(deposite: payment):
                        if someBank.checkMaxAccountDeposit(withdraw: payment) {
                            someBank.topUpPhoneBalanceDeposit(pay: payment)
                            someBank.showUserToppedUpMobilePhoneDeposite(deposite: payment)
                        }
                        else {
                            someBank.showError(error: .incorrect_deposit)
                        }
                    }
                }
            }
            else{
                someBank.showError(error: .incorrect_data_phone)
            }
        case let .userChooseTopUpDeposite(topUpDeposite: payment):
            if someBank.checkMaxUserCash(cash: payment) {
                someBank.putCashDeposit(topUp: payment)
                someBank.showTopUpAccount(cash: payment)
            }
            else {
                someBank.showError(error: .incorrect_cash)
            }
        case let .userChooseWithdrawDeposite(withdrawDeposite: payment):
            if someBank.checkMaxAccountDeposit(withdraw: payment) {
                someBank.getCashFromDeposit(cash: payment)
                someBank.showWithdrawalDeposit(cash: payment)
            }
            else {
                someBank.showError(error: .incorrect_deposit)
            }
        }
     }
    else {
        someBank.showError(error: .incorrect_data_card)
    }
  }
}

struct BankServer: BankApi {
    private var user:UserData
   
    init(user: UserData){
        self.user = user
    }
    
    public func showUserBalance() {
        let report = """
            Здравствуйте, \(user.userName)
            \(DescriptionTypesAvailableOperations.viewBalance.rawValue)
            Ваш баланс составляет \(user.userBankDeposit) рублей.
            """
        print(report)
    }
    
    public func showUserToppedUpMobilePhoneCash(cash: Float) {
        let report = """
            Здравствуйте, \(user.userName)
            \(DescriptionTypesAvailableOperations.topUpPhoneBalance.rawValue)
            Вы пополнили баланс наличными на сумму : \(cash)
            У вас осталось наличными \(user.userCash) рублей.
            Баланс вашего телефона составляет \(user.useerPhoneBalance) рублей.
            """
        print(report)
    }
    
    public func showUserToppedUpMobilePhoneDeposite(deposite: Float) {
        let report = """
            Здрвствуйте, \(user.userName)
            \(DescriptionTypesAvailableOperations.topUpPhoneBalance.rawValue)
            Вы поплнили баланс c депозита на сумму \(deposite) рублей.
            Баланс вашего телефона составляет \(user.useerPhoneBalance) рублей.
            """
        print(report)
    }
    
    public func showWithdrawalDeposit(cash: Float) {
        let report = """
            Здрвствуйте, \(user.userName)
            \(DescriptionTypesAvailableOperations.withdrawDeposite.rawValue)
            Вы сняли с депозита денежных средств на сумму \(cash) рублей.
            Ваш баланс на карте составляет \(user.userBankDeposit) рублей.
            Сумма ваших наличных составляет \(user.userCash) рублей.
            """
        print(report)
    }
    
    public func showTopUpAccount(cash: Float) {
        let report = """
            Здравствуйте, \(user.userName)
            \(DescriptionTypesAvailableOperations.topUpDeposite.rawValue)
            Вы поплнили депозит на сумму \(cash) рублей.
            Ваш баланс на карте составляет \(user.userBankDeposit) рублей.
            Сумма ваших наличных составляет \(user.userCash) рублей.
            """
        print(report)
    }
    
    public func showError(error: TextErrors) {
        let report = """
            Здравствуйте, \(user.userName)
            Возникла ошибка \(error.rawValue)
            """
        print(report)
    }
    
    public func checkUserPhone(phone: String) -> Bool {
        if phone == user.userPhone {
            return true
        } else {
            return false
        }
    }
    
    public func checkMaxUserCash(cash: Float) -> Bool {
        if cash <= user.userCash {
            return true
        } else {
            return false
        }
    }

    
    public func checkMaxAccountDeposit(withdraw: Float) -> Bool {
        if withdraw <= user.userBankDeposit {
            return true
        } else {
            return false
        }
    }
    
    public func checkCurrentUser(userCardId: String, userCardPin: Int) -> Bool {
        let isCorrectId = checkId(id: user.userCardId, user: user)
        let isCorrectPin = checkPin(pin: user.userCardPin, user: user)
        if isCorrectId && isCorrectPin {
            return true
        }
        return false
    }
    
    public func checkId(id: String, user: UserData) -> Bool {
        if id == user.userCardId {
            return true
        } else {
            return false
        }
        
    }
    
    public func checkPin(pin: Int, user: UserData) -> Bool {
        if pin == user.userCardPin {
            return true
        } else {
            return false
        }
    }
    
    public mutating func topUpPhoneBalanceCash(pay: Float) {
        user.useerPhoneBalance += pay
        user.userCash -= pay
    }
    
    public mutating func topUpPhoneBalanceDeposit(pay: Float) {
        user.useerPhoneBalance += pay
        user.userBankDeposit -= pay
    }
    
    public mutating func getCashFromDeposit(cash: Float) {
        user.userBankDeposit -= cash
        user.userCash += cash
    }
    
    public mutating func putCashDeposit(topUp: Float) {
        user.userCash -= topUp
        user.userBankDeposit += topUp
    }
}
let ivanIvanov: UserData = User(
    userName: "Иван Иванов",
    userCardId: "5124 7432 9912 0032",
    userCardPin: 7633,
    userCash: 1200,
    userBankDeposit: 4373.6,
    userPhone: "+7917-937-21-64",
    useerPhoneBalance: -231)

let finBetaBank = BankServer(user: ivanIvanov)

let atm1 = ATM(userCardId: "5124 7432 9912 0032", userCardPin: 7631, someBank: finBetaBank, action: .userChooseViewBalance)
